<?php

	if (strlen(session_id()) < 1) {	session_start(); }//Validamos si existe o no la sesión

	require_once "../modelos/Persona.php";
	require_once "../modelos/Ciudad.php";
	require_once "../modelos/Departamento.php";
	require_once "../modelos/Distrito.php";

	
	
	$persona 				= new Persona();	
	$_ciudad 				= new Ciudad();	
	$_departamento 	= new Departamento();	
	$_distrito 			= new Distrito();
	

	$idpersona 				= isset($_POST["idpersona"]) ? limpiarCadena($_POST["idpersona"]) : "";
	$tipo_persona 		= isset($_POST["tipo_persona"]) ? limpiarCadena($_POST["tipo_persona"]) : "";
	$nombres 					= isset($_POST["nombres"]) ? limpiarCadena($_POST["nombres"]) : "";
	$apellidos 				= isset($_POST["apellidos"]) ? limpiarCadena($_POST["apellidos"]) : "";
	$tipo_documento 	= isset($_POST["tipo_documento"]) ? limpiarCadena($_POST["tipo_documento"]) : "";
	$numero_documento = isset($_POST["numero_documento"]) ? limpiarCadena($_POST["numero_documento"]) : "";
	$nruc 						= isset($_POST["numero_documento3"]) ? limpiarCadena($_POST["numero_documento3"]) : ""; //Viene de nuevo cliente
	$razon_social 		= isset($_POST["razon_social"]) ? limpiarCadena($_POST["razon_social"]) : "";
	$nombre_comercial = isset($_POST["nombre_comercial"]) ? limpiarCadena($_POST["nombre_comercial"]) : "";
	$domicilio_fiscal = isset($_POST["domicilio_fiscal"]) ? limpiarCadena($_POST["domicilio_fiscal"]) : "";
	$departamento 		= isset($_POST["iddepartamento"]) ? limpiarCadena($_POST["iddepartamento"]) : "";
	$ciudad 					= isset($_POST["idciudad"]) ? limpiarCadena($_POST["idciudad"]) : "";
	$distrito 				= isset($_POST["iddistrito"]) ? limpiarCadena($_POST["iddistrito"]) : "";
	$telefono1 				= isset($_POST["telefono1"]) ? limpiarCadena($_POST["telefono1"]) : "";
	$telefono2 				= isset($_POST["telefono2"]) ? limpiarCadena($_POST["telefono2"]) : "";
	$email 						= isset($_POST["email"]) ? limpiarCadena($_POST["email"]) : "";

	$razon_social3 		= isset($_POST["razon_social3"]) ? limpiarCadena($_POST["razon_social3"]) : "";
	$nombre_comercial3 = isset($_POST["razon_social3"]) ? limpiarCadena($_POST["razon_social3"]) : "";
	$domicilio_fiscal3 = isset($_POST["domicilio_fiscal3"]) ? limpiarCadena($_POST["domicilio_fiscal3"]) : "";

switch ($_GET["op"]) {

	case 'guardaryeditar':
		$validando = $persona->validarProveedor($numero_documento, $tipo_persona);
		
			if (empty($idpersona)) {
				if (empty($validando)) {
					$rspta = $persona->insertar($tipo_persona, htmlspecialchars_decode($nombres), htmlspecialchars_decode($apellidos), $tipo_documento, $numero_documento, htmlspecialchars_decode($razon_social), htmlspecialchars_decode($nombre_comercial), htmlspecialchars_decode($domicilio_fiscal), $departamento, $ciudad, $distrito, $telefono1, $telefono2, htmlspecialchars_decode($email));
					echo $rspta ? "Registro correcto" : "No se pudo registrar";
				} else {
					echo "duplicado" ;
				}		
			} else {
				$rspta = $persona->editar($idpersona, $tipo_persona, $nombres, $apellidos, $tipo_documento, $numero_documento, $razon_social, $nombre_comercial, $domicilio_fiscal, $departamento, $ciudad, $distrito, $telefono1, $telefono2, $email);
				echo $rspta ? "Registro actualizado" : "No se pudo actualizar";
			}
		
	break;

	case 'guardaryeditarnproveedor':
		$rspta = $persona->insertarnproveedor($tipo_persona, $numero_documento, htmlspecialchars_decode($razon_social));
		echo $rspta ? "Registro correcto" : "No se pudo registrar";
	break;

	case 'guardaryeditarNcliente':
		if (empty($idpersona)) {
			$rspta = $persona->insertar($tipo_persona, htmlspecialchars_decode($nombres), htmlspecialchars_decode($apellidos), $tipo_documento, $nruc, htmlspecialchars_decode($razon_social), htmlspecialchars_decode($nombre_comercial), htmlspecialchars_decode($domicilio_fiscal), $departamento, $ciudad, $distrito, $telefono1, $telefono2, htmlspecialchars_decode($email));
			echo $rspta ? "Registro correcto" : "No se pudo registrar";
		} else {
			$rspta = $persona->editar($idpersona, $tipo_persona, htmlspecialchars_decode($nombres), htmlspecialchars_decode($apellidos), $tipo_documento, $nruc, htmlspecialchars_decode($razon_social), htmlspecialchars_decode($nombre_comercial), htmlspecialchars_decode($domicilio_fiscal), $departamento, $ciudad, $distrito, $telefono1, $telefono2, htmlspecialchars_decode($email));
			echo $rspta ? "Registro actualizado" : "No se pudo actualizar";
		}
	break;

	case 'guardaryeditarNclienteBoleta':
		if (empty($idpersona)) {
			$rspta = $persona->insertar($tipo_persona, htmlspecialchars_decode($nombre_comercial3), htmlspecialchars_decode($nombre_comercial3), $tipo_documento, $nruc, htmlspecialchars_decode($razon_social3), htmlspecialchars_decode($nombre_comercial3), htmlspecialchars_decode($domicilio_fiscal3), '14', '43', '96', $telefono1, $telefono2, htmlspecialchars_decode($email));
			echo $rspta ? "Registro correcto" : "No se pudo registrar";
		} else {
			$rspta = $persona->editar($idpersona, $tipo_persona, htmlspecialchars_decode($nombre_comercial3), htmlspecialchars_decode($nombre_comercial3), $tipo_documento, $nruc, htmlspecialchars_decode($razon_social3), htmlspecialchars_decode($nombre_comercial3), htmlspecialchars_decode($domicilio_fiscal3), $departamento, $ciudad, $distrito, $telefono1, $telefono2, htmlspecialchars_decode($email));
			echo $rspta ? "Registro actualizado" : "No se pudo actualizar";
		}
	break;

	case 'eliminar':
		$rspta = $persona->eliminar($idpersona);
		echo $rspta ? "Persona desactivada" : "Persona no se puede activar";
	break;

	case 'mostrar':
		$rspta = $persona->mostrar($idpersona);
		//Codificar el resultado utilizando json
		echo json_encode($rspta);
	break;

	//quitar id persona por validacion
	case 'mostrarClienteVarios':
		$rspta = $persona->mostrarIdVarios($idpersona);
		//Codificar el resultado utilizando json
		echo json_encode($rspta);
	break;

	case 'desactivar':
		$rspta = $persona->desactivar($idpersona);
		echo $rspta ? "Persona Desactivado" : "Persona no se puede desactivar";
	break;

	case 'activar':
		$rspta = $persona->activar($idpersona);
		echo $rspta ? "Persona activado" : "Persona no se puede activar";
	break;

	case 'listarp':
		$rspta = $persona->listarp();
		//Vamos a declarar un array
		$data = array();

		while ($reg = $rspta->fetch_object()) {
			$data[] = array(
				"0" => '<button class="btn btn-icon btn-sm btn-warning" onclick="mostrar(' . $reg->idpersona . ')"><i class="ri-edit-line"></i></button>'.
					($reg->estado ? ' <button class="btn btn-icon btn-sm btn-danger" onclick="desactivar(' . $reg->idpersona . ')"><i class="ri-delete-bin-line"></i></button>' :
					' <button class="btn btn-icon btn-sm btn-success" onclick="activar(' . $reg->idpersona . ')"><i class="ri-check-double-line"></i></button>'),

				"1" =>  ($reg->tipo_doc == 'RUC' ? $reg->razon_social : $reg->nombres . ' '. $reg->apellidos ),
				"2" => '<b>' . $reg->tipo_doc .'</b>: '. $reg->numero_documento,
				"3" => $reg->telefono1,
				"4" => $reg->email,
				"5" => ($reg->estado) ? '<span class="badge bg-success-transparent"><i class="ri-check-fill align-middle me-1"></i>Activo</span>' : '<span class="badge bg-danger-transparent"><i class="ri-close-fill align-middle me-1"></i>Inhabilitado</span>'
			);
		}
		$results = array(
			"sEcho" => 1, //Información para el datatables
			"iTotalRecords" => count($data), //enviamos el total registros al datatable
			"iTotalDisplayRecords" => count($data), //enviamos el total registros a visualizar
			"aaData" => $data
		);
		echo json_encode($results);
	break;

	case 'listarc':
		$rspta = $persona->listarc();
		//Vamos a declarar un array
		$data = array();

		while ($reg = $rspta->fetch_object()) {
			$data[] = array(
				"0" => '<button class="btn btn-icon btn-sm btn-warning" onclick="mostrar(' . $reg->idpersona . ')"><i class="fa fa-pencil"> </i></button>' .
					($reg->estado ? ' <button class="btn btn-icon btn-sm btn-danger" onclick="desactivar(' . $reg->idpersona . ')"><i class="fa fa-close" ></i></button> ' :
					' <button class="btn btn-icon btn-sm btn-success" onclick="activar(' . $reg->idpersona . ')"><i class="fa fa-check" ></i></button> '),

				"1" => ($reg->tipo_doc == 'RUC' ? $reg->razon_social : $reg->nombres . ' '. $reg->apellidos ),
				"2" => $reg->tipo_doc,
				"3" => $reg->numero_documento,
				"4" => $reg->telefono1,
				"5" => $reg->email,
				"6" => ($reg->estado) ? '<span class="badge bg-success-transparent"><i class="ri-check-fill align-middle me-1"></i>Activo</span>' : '<span class="badge bg-danger-transparent"><i class="ri-close-fill align-middle me-1"></i>Inhabilitado</span>'
			);
		}
		$results = array(
			"sEcho" => 1, //Información para el datatables
			"iTotalRecords" => count($data), //enviamos el total registros al datatable
			"iTotalDisplayRecords" => count($data), //enviamos el total registros a visualizar
			"aaData" => $data
		);
		echo json_encode($results, true);
	break;

	

	// ══════════════════════════════════════ S E L E C T 2   ══════════════════════════════════════

	case 'selectCiudad':		
		$rspta = $_ciudad->selectC($_GET['id']);
		while ($reg = $rspta->fetch_object()) {
			echo '<option value=' . $reg->idciudad . '>' . $reg->nombre . '</option>';
		}
	break;

	case 'selectDistrito':		
		$id = $_GET['id'];
		$rspta = $_distrito->selectDI($id);
		while ($reg = $rspta->fetch_object()) {
			echo '<option value=' . $reg->iddistrito . '>' . $reg->nombre . '</option>';
		}
	break;

	case 'ValidarCliente':
		$ndocumento = $_GET['ndocumento'];
		$rspta = $persona->validarCliente($ndocumento);
		echo json_encode($rspta); // ? "Cliente ya existe": "Documento valido";
	break;

	case 'ValidarProveedor':
		$ndocumento = $_GET['ndocumento'];
		$rspta = $persona->validarProveedor($ndocumento, $_GET['tipo_persona']);
		echo json_encode($rspta); // ? "Cliente ya existe": "Documento valido";
	break;

	case 'selectCliente':
		$rspta = $persona->listarc();
		while ($reg = $rspta->fetch_object()) {
			echo '<option value=' . $reg->idpersona . '>' . $reg->numero_documento . '</option>';
		}
	break;

	// ══════════════════════════════════════ Reniec   ══════════════════════════════════════
	case 'buscarclienteRuc':		
		$rspta = $persona->buscarclienteRuc($_POST['key']);
		foreach ($rspta as $key => $row) {
			$id = $row['idpersona'];
			$num_doc = utf8_encode($row['numero_documento']);
			$razon_s = utf8_encode($row['razon_social']);
			$dom_fiscal = utf8_encode($row['domicilio_fiscal']);
			$html = '<div ><a class="suggest-element"  ndocumento="'.$num_doc.'"  ncomercial="' . $razon_s . '"  domicilio="' . $dom_fiscal . '" id="' . $id . '" email="' . $row['email'] . '">' . $razon_s . '</a></div>';
			echo $html;
		}
	break;

	case 'buscarclienteDomicilio':
		// $key = $_POST['key'];
		$rspta = $persona->buscarclientenombre($_POST['key']);
		
		foreach ($rspta as $key => $row) {
			$id = $row['idpersona'];
			$num_doc = utf8_encode($row['numero_documento']);
			$razon_s = utf8_encode($row['razon_social']);
			$dom_fiscal = utf8_encode($row['domicilio_fiscal']);
			echo '<div><a class="suggest-element"  ndocumento="' . $num_doc . '"  ncomercial="' . $razon_s . '"  domicilio="' . $dom_fiscal . '" id="' . $id . '" email="' . $row['email'] . '">' . $razon_s . '</a></div>';
		}
	break;

	case 'combocliente':
		$rpta = $persona->combocliente();
		while ($reg = $rpta->fetch_object()) {
			echo '<option value=' . $reg->numero_documento . '>' . $reg->numero_documento . ' | ' . $reg->nombre_comercial . '</option>';
		}
	break;

	case 'comboclientenoti':
		$rpta = $persona->combocliente();
		while ($reg = $rpta->fetch_object()) {
			echo '<option value=' . $reg->idpersona . '>' . $reg->numero_documento . ' | ' . $reg->nombre_comercial . '</option>';
		}
	break;
}
