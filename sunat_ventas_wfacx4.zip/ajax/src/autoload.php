<?php
	require (__DIR__ . "/curl.php");
	require (__DIR__ . "/essalud/essalud.php");
	require (__DIR__ . "/mintra/mintra.php");
	require (__DIR__ . "/reniec/reniec.php");
	require (__DIR__ . "/reniec/solver.php");
?>
