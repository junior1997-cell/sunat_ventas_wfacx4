<?php
//Activamos el almacenamiento del Buffer
// ob_start();
// session_start();

// if (!isset($_SESSION["nombre"]))
// {
//   header("Location: ../vistas/login.php");
// }
// else
// {
// require 'header.php';

// if($_SESSION['almacen']==1)
// {
// ?>
<!--Contenido-->