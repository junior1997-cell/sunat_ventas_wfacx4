<?php
// Redireccionar a la vista login
header('Location: ../vistas/login.php');
?>
