var tabla;
var modoDemo = false;


//Función que se ejecuta al inicio

function init() {
	mostrarform(false);
	//mostrar("1");
	listar();
	$("#formulario").on("submit", function (e) {guardaryeditar(e);});
}

function limpiar() {
	$("#idempresa").val("");
	$("#razonsocial").val("");
	$("#ncomercial").val("");
	$("#domicilio").val("");
	$("#ruc").val("");
	$("#tel1").val("");
	$("#tel2").val("");
	$("#correo").val("");
	$("#web").val("");
	$("#webconsul").val("");
	$("#imagenmuestra").attr("src", "../files/logo/img_defecto.png");
	$("#imagenactual").val("");
	$("#ubigueo").val("");
	$("#codubigueo").val("");
	$("#ciudad").val("");
	$("#distrito").val("");
	$("#interior").val("");
	$("#codigopais").val("");
	$("#igv").val("");
	$("#porDesc").val("");
	$("#razonsocial").focus();
	$("#preview").empty();
}

//Función cancelarform
function cancelarform() {	mostrarform(false); }

//Función para guardar o editar
function guardaryeditar(e) {
	e.preventDefault(); //No se activará la acción predeterminada del evento
	if (modoDemo) {
		Swal.fire({
			icon: 'warning',
			title: 'Modo demo',
			text: 'No puedes editar o guardar en modo demo',
		});
		return;
	}
	//$("#btnGuardar").prop("disabled",true);

	var formData = new FormData($("#formulario")[0]);
	$.ajax({
		url: "../ajax/empresa.php?op=guardaryeditar",
		type: "POST",
		data: formData,
		contentType: false,
		processData: false,
		success: function (datos) {
			Swal.fire({
				icon: 'success',
				title: 'Éxito',
				text: datos,
				showConfirmButton: true,				
			});
			mostrarform(false);
			//var int = self.setInterval("refresh()",1000);
			listar();
		}
	});
}

function mostrarform(flag) {
	limpiar();
	if (flag == true) {
		$("#listadoregistros").hide();
		$("#formularioregistros").show();
		$("#btnGuardar").prop("disabled", false);
		$("#btnagregar").hide();
		$("#preview").empty();
	}else {
		$("#listadoregistros").show();
		$("#formularioregistros").hide();
		$("#btnagregar").show();
	}
}

function mostrar(idempresa) {
	$.post("../ajax/empresa.php?op=mostrar", { idempresa: idempresa }, function (data, status) {
		data = JSON.parse(data);
		mostrarform(true);
		$("#idempresa").val(data.idempresa);
		$("#razonsocial").val(data.nombre_razon_social);
		$("#ncomercial").val(data.nombre_comercial);
		$("#domicilio").val(data.domicilio_fiscal);
		$("#ruc").val(data.numero_ruc);
		$("#tel1").val(data.telefono1);
		$("#tel2").val(data.telefono2);
		$("#correo").val(data.correo);
		$("#web").val(data.web);
		$("#webconsul").val(data.webconsul);
		//$("#imagenmuestra").attr("src","../files/logo/"+data.logo);
		$("#imagenmuestra").show();

		if (data.logo == "" || data.logo == null ) {
			$("#imagenmuestra").attr("src", "../files/logo/img_defecto.png");
			//$("#imagenmuestra").attr("src","c:/sfs/files/logo/simagen.png");
			$("#imagenactual").val("");
			$("#imagen").val("");
		} else {
			$("#imagenmuestra").attr("src", '../files/logo/' + data.logo);
			//$("#imagenmuestra").attr("src","c://sfs//files//logo//" + data.logo);
			$("#imagenactual").val(data.logo);
			$("#imagen").val("");
		}

		//$("#imagenactual").val(data.logo);
		$("#ubigueo").val(data.ubigueo);
		$("#codubigueo").val(data.codubigueo);
		$("#ciudad").val(data.ciudad);
		$("#distrito").val(data.distrito);
		$("#interior").val(data.interior);
		$("#codigopais").val(data.codigopais);

		//Configuraciones
		$("#igv").val(data.igv);
		$("#porDesc").val(data.porDesc);
		$("#banco1").val(data.banco1);
		$("#cuenta1").val(data.cuenta1);
		$("#banco2").val(data.banco2);
		$("#cuenta2").val(data.cuenta2);
		$("#banco3").val(data.banco3);
		$("#cuenta3").val(data.cuenta3);
		$("#banco4").val(data.banco4);
		$("#cuenta4").val(data.cuenta4);
		$("#cuentacci1").val(data.cuentacci1);
		$("#cuentacci2").val(data.cuentacci2);
		$("#cuentacci3").val(data.cuentacci3);
		$("#cuentacci4").val(data.cuentacci4);
		$("#tipoimpresion").val(data.tipoimpresion);
		$("#textolibre").val(data.textolibre);
	});
}

function listar() {
	tabla = $('#tbllistado').dataTable({
			"aProcessing": true,//Activamos el procesamiento del datatables
			"aServerSide": true,//Paginación y filtrado realizados por el servidor
			dom: 'Bfrtip',//Definimos los elementos del control de tabla
			buttons: [],
			"ajax":	{
				url: '../ajax/empresa.php?op=listar',
				type: "get",
				dataType: "json",
				error: function (e) {
					console.log(e.responseText);
				}
			},
			"bDestroy": true,
			"iDisplayLength": 5,//Paginación
			"order": [[0, "desc"]]//Ordenar (columna,orden)
		}).DataTable();
}

document.getElementById("imagen").onchange = function (e) {
	// Creamos el objeto de la clase FileReader
	let reader = new FileReader();

	// Leemos el archivo subido y se lo pasamos a nuestro fileReader
	reader.readAsDataURL(e.target.files[0]);

	// Le decimos que cuando este listo ejecute el código interno
	reader.onload = function () {
		// let preview = document.getElementById('preview'),	image = document.createElement('img');
		// image.src = reader.result;
		// image.width = '100';
		// image.height = 'auto';
		// preview.innerHTML = '';
		// preview.append(image);
		$('#imagenmuestra').attr('src', reader.result);
	};
}

init();

function buscar_sunat(input = '', input_numdoc) {
	var num_ruc= $(input_numdoc).val();
	$.post("../ajax/ajax_general.php?op=sunat", {ruc: num_ruc},	function (e, textStatus, jqXHR) {
		e = JSON.parse(e);

	});
}