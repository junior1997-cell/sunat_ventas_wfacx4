var fecha = new Date();
var ano = fecha.getFullYear();
var mes=fecha.getMonth();


$("#ano").val(ano);
$("#mes").val(mes+1);